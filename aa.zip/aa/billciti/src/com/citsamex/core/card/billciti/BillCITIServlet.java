package com.citsamex.core.card.billciti;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.namespace.QName;

import org.apache.axis.client.Call;
import org.apache.axis.client.Service;

import com.citsamex.core.card.util.Strings;


public class BillCITIServlet extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

//		response.setContentType("text/html");
//		PrintWriter out = response.getWriter();
		doPost(request,response);
//		out.flush();
//		out.close();
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
//http://127.0.0.1:8080/billciti/billciti.do??ProcCode=0210&AccountNum=1413800138000|62251234567890&ProcessCode=190000&Amount=000000029.99&CurCode=01&TransDatetime=0423052346&AcqSsn=052346&Ltime=052346&Ldate=0423&Reference=05110130423052345540&ReturnAddress=02http://203.187.170.31:88/payment/easyRetProcess.do?ENCODING=UTF-8&RespCode=T404&Remark=֧��ʧ�ܣ�ԭ�򣬶������������ݲ�֧�ֵĿ���&TerminalNo=05023141&MerchantNo=02202020000058&OrderNo=01202013042200078079&OrderState=05&Description=�ֻ���ٽɻ��ￄ1�7&OrderType=00&TransData=�|610100198812029632|����|01|��ҵ����|203.187.170.39||13657612345|||&Mac=0C74C5068014473159F33435A74383EC
		System.out.println("doPost................");
//		dnapay.common.ToolKit.writeLog(this.getClass().getName(), "doGet", request.getRemoteAddr());
        request.setCharacterEncoding("gbk");
        response.setCharacterEncoding("gbk");
        response.setContentType("text/html;charset=gbk");
        try {
//            PosMessage httpOrder = new PosMessage();
        	StringBuffer sb = new StringBuffer();
        	sb.append("{");
        	String encoding = request.getParameter("ENCODING")!= null?request.getParameter("ENCODING"):"gbk";
        	String[] strs2 = new String[]{"Description","Remark","TransData"};
        	for (int i = 0; i < strs2.length; i++) {
        		String tempvalue = request.getParameter(strs2[i]);
        		if (!Strings.isNullOrEmpty(tempvalue)) {
        			sb.append("\"").append(strs2[i]).append("\"").append(":\"");
        			sb.append(request.getParameter(strs2[i]));
        			sb.append("\",");
        		}
        	}
        	String[] strs1 = new String[]{"ReturnAddress","ProcCode","AccountNum","ProcessCode",
        			"Amount","CurCode","TransDatetime","AcqSsn","Ltime","Ldate","SettleDate","UpsNo",
        			"TsNo","Reference","RespCode","TerminalNo","MerchantNo","OrderNo","OrderState",
        			"ValidTime","OrderType","Pin","LoginPin","Mac"};
        	
        	for (int i = 0,length = strs1.length; i < length; i++) {
        		String tempvalue = request.getParameter(strs1[i]);
        		if (!Strings.isNullOrEmpty(tempvalue)) {
        			sb.append("\"").append(strs1[i]).append("\"").append(":\"");
        			sb.append(tempvalue).append("\"");
        			if(i != length -1)
        				sb.append(",");
        		}
			}
        	sb.append("}");
        	System.out.println(sb.toString());
        	
//        	String url = "http://10.181.3.30:8080/kao/services/UpdatebillCITIWebservice?wsdl";
        	//TEST
//        	String url = "http://10.181.10.138:8080/kao/services/UpdatebillCITIWebservice?wsdl";
        	String url = readProperty("url");
        	Service serv = new Service();
        	Call call = (Call) serv.createCall();
        	call.setTargetEndpointAddress(url);
        	call.setOperationName(new QName(url,"update"));
        	String result = (String) call.invoke(new Object[]{sb.toString()});
        	System.out.println("result=" + result);
        	if ("success".equals(result)) {
        		  BufferedOutputStream out = new BufferedOutputStream(response.getOutputStream());
                  out.write("0000".getBytes());
                  out.flush();
                  out.close();
			}
//            System.out.println("request.getParameter(ReturnAddress)="+request.getParameter("ReturnAddress"));
//            sb.append("ReturnAddress:");
//            sb.append(request.getParameter("ReturnAddress"));
//            sb.append(",");
//            
//            System.out.println("request.getParameter(ProcCode)="+request.getParameter("ProcCode"));
//            sb.append("ProcCode:");
//            sb.append(request.getParameter("ProcCode"));
//            sb.append(",");

//            System.out.println("request.getParameter(AccountNum)="+request.getParameter("AccountNum"));
//            sb.append("AccountNum:");
//            sb.append(request.getParameter("AccountNum"));
//            sb.append(",");
            
//            System.out.println("request.getParameter(ProcessCode)="+request.getParameter("ProcessCode"));
//            sb.append("ProcessCode:");
//            sb.append(request.getParameter("ProcessCode"));
//            sb.append(",");
            
//            System.out.println("request.getParameter(Amount)="+request.getParameter("Amount"));
//            sb.append("Amount:");
//            sb.append(request.getParameter("Amount"));
            
//            System.out.println("request.getParameter(CurCode)="+request.getParameter("CurCode"));
//            sb.append("CurCode:");
//            sb.append(request.getParameter("CurCode"));
            
//            System.out.println("request.getParameter(TransDatetime)="+request.getParameter("TransDatetime"));
//            sb.append("TransDatetime:");
//            sb.append(request.getParameter("TransDatetime"));
            
//            System.out.println("request.getParameter(AcqSsn)="+request.getParameter("AcqSsn"));
//            sb.append("AcqSsn:");
//            sb.append(request.getParameter("AcqSsn"));
            
//            System.out.println("request.getParameter(Ltime)="+request.getParameter("Ltime"));
//            sb.append("Ltime:");
//            sb.append(request.getParameter("Ltime"));
            
//            System.out.println("request.getParameter(Ldate="+request.getParameter("Ldate"));
//            sb.append("Ldate:");
//            sb.append(request.getParameter("Ldate"));
            
//            System.out.println("request.getParameter(SettleDate)="+request.getParameter("SettleDate"));
//            sb.append("SettleDate:");
//            sb.append(request.getParameter("SettleDate"));
            
//            System.out.println("request.getParameter(UpsNo)="+request.getParameter("UpsNo"));
//            sb.append("UpsNo:");
//            sb.append(request.getParameter("UpsNo"));
            
//            System.out.println("request.getParameter(TsNo)="+request.getParameter("TsNo"));
//            sb.append("TsNo:");
//            sb.append(request.getParameter("TsNo"));
            
//            System.out.println("request.getParameter(Reference)="+request.getParameter("Reference"));
//            sb.append("Reference:");
//            sb.append(request.getParameter("Reference"));
            
//            System.out.println("request.getParameter(RespCode)="+request.getParameter("RespCode"));
//            sb.append("RespCode:");
//            sb.append(request.getParameter("RespCode"));
//            System.out.println("request.getParameter(TerminalNo)="+request.getParameter("TerminalNo"));
//            sb.append("ReturnAddress:");
//            sb.append(request.getParameter("TerminalNo"));
//            System.out.println("request.getParameter(MerchantNo)="+request.getParameter("MerchantNo"));
//            sb.append("ReturnAddress:");
//            sb.append(request.getParameter("MerchantNo"));
//            System.out.println("request.getParameter(OrderNo)="+request.getParameter("OrderNo"));
//            sb.append("ReturnAddress:");
//            sb.append(request.getParameter("OrderNo"));
//            System.out.println("request.getParameter(OrderState)="+request.getParameter("OrderState"));
//            sb.append("ReturnAddress:");
//            sb.append(request.getParameter("OrderState"));
//            if (!Strings.isNullOrEmpty(request.getParameter("Description"))) {
//            	sb.append("ReturnAddress:");
//            	sb.append(new String(request.getParameter("Description").getBytes("ISO8859-1"), "GBK"));
//            }
//            if (!Strings.isNullOrEmpty(request.getParameter("Remark"))) {
//            	sb.append("ReturnAddress:");
//            	sb.append(new String(request.getParameter("Remark").getBytes("ISO8859-1"), "GBK"));
//            }
//            sb.append("ReturnAddress:");
//            sb.append(request.getParameter("ValidTime"));
//            sb.append("ReturnAddress:");
//            sb.append(request.getParameter("OrderType"));
//            if (!Strings.isNullOrEmpty(request.getParameter("TransData"))) {
//            	sb.append("ReturnAddress:");
//            	sb.append(new String(request.getParameter("TransData").getBytes("ISO8859-1"), "GBK"));
//            }
//            sb.append("ReturnAddress:");
//            sb.append(request.getParameter("Pin"));
//            sb.append("ReturnAddress:");
//            sb.append(request.getParameter("LoginPin"));
//            System.out.println("request.getParameter(Mac)="+request.getParameter("Mac"));
//            sb.append("ReturnAddress:");
//            sb.append(request.getParameter("Mac"));

//            ToolKit.writeLog(this.getClass().getName(), "request", httpOrder.toString());

            
//            System.out.println(httpOrder.getRespCode()+"........................");
//            System.out.println(httpOrder.getMac()+"2323232200000000000");
//            System.out.println(httpOrder.getMac()+"qqqqqqqqqqqqqqqqqqqqqqqqq");
            

          
        } catch (Exception e) {
        	System.out.println("call webservices error.");
//            ToolKit.writeLog(this.getClass().getName(), "doGet", e);
        	System.out.println(e.getMessage());
        	e.printStackTrace();
        }

	}
	
	public String readProperty(String key) {
		String value = "";
		String properiesName = "config.properties";
		InputStream is = null;
		try {
			is = BillCITIServlet.class.getClassLoader().getResourceAsStream(
					properiesName);
			Properties p = new Properties();
			p.load(is);
			value = p.getProperty(key);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (is != null) {
					is.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public static void main(String[] args) {
		BillCITIServlet b = new BillCITIServlet();
		System.out.println(b.readProperty("url"));
	}

}
