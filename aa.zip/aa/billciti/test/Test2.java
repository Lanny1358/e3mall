import java.rmi.RemoteException;

import javax.xml.namespace.QName;
import javax.xml.rpc.ServiceException;

import org.apache.axis.client.Call;
import org.apache.axis.client.Service;


public class Test2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		String json = "{\"Description\":\"��Ʊ����\",\"Remark\":\"֧���ɹ�\",\"TransData\":\"FUAT CTA FUAT CTA|51356564||02|��������||||||02	!	test0002||\",\"ReturnAddress\":\"02http://210.13.127.41:7080/billciti/billciti.do?ENCODING=GBK\",\"ProcCode\":\"0210\",\"AccountNum\":\"2113817935885|6250751020007821\",\"ProcessCode\":\"190000\",\"Amount\":\"000000001.00\",\"CurCode\":\"01\",\"TransDatetime\":\"0109110933\",\"AcqSsn\":\"110922\",\"Ltime\":\"110933\",\"Ldate\":\"0109\",\"SettleDate\":\"0109\",\"UpsNo\":\"000000000070\",\"TsNo\":\"093357\",\"Reference\":\"reference\",\"RespCode\":\"0000\",\"TerminalNo\":\"02028828\",\"MerchantNo\":\"02502020000844\",\"OrderNo\":\"12261319|502014010972312059\",\"OrderState\":\"02\",\"ValidTime\":\"20140116111044\",\"OrderType\":\"00\",\"Pin\":\"null\",\"LoginPin\":\"null\",\"Mac\":\"1E1D427D165E73AF1618D16985934A03\"}";

		String url = "http://10.181.10.138:8080/kao/services/UpdatebillCITIWebservice?wsdl";
    	Service serv = new Service();
    	Call call;
		try {
			call = (org.apache.axis.client.Call) serv.createCall();
			call.setTargetEndpointAddress(url);
			call.setOperationName(new QName(url,"update"));
			String result = (String) call.invoke(new Object[]{json});
			System.out.println("result=" + result);
		} catch (ServiceException e) {
			e.printStackTrace();
		} catch (RemoteException e) {
			e.printStackTrace();
		}
//		String a = "12261257|302013092900014486";
//		int str  = a.indexOf("|");
//		System.out.println(a.substring(2,str));
//		long id = Long.parseLong(a.substring(2,str));
	}

}
