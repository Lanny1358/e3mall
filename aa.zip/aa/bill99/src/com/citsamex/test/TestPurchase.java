package com.citsamex.test;

import com.citsamex.core.card.bill99.Bill99Service;

public class TestPurchase {
	public static void main(String[] args) throws Exception {
		System.setProperty("jsse.enableSNIExtension", "false");
		System.out.println(System.getProperty("jsse.enableSNIExtension"));
//		String xml1 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
//				+ "<MasMessage xmlns=\"http://www.99bill.com/mas_cnp_merchant_interface\">"
//				+ "<version>1.0</version><TxnMsgContent><txnType>PUR</txnType><interactiveStatus>TR1</interactiveStatus><merchantId>812310045110196</merchantId><terminalId>00002115</terminalId><entryTime>20160329181859</entryTime><cardNo>4581240910584102</cardNo><expiredDate>0520</expiredDate><amount>1.00</amount><externalRefNumber>T0000816653</externalRefNumber><tr3Url>http://183.91.145.196:7080/bill99/bill99tr3.do</tr3Url><ext>kao</ext><ext1>EJ0329181822</ext1><extMap><extDate><key>cellPhone</key><value>13611153356</value></extDate><extDate><key>idType</key><value>0</value></extDate><extDate><key>phone</key><value>13611153356</value></extDate></extMap></TxnMsgContent></MasMessage>";
		String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
				+ "<MasMessage xmlns=\"http://www.99bill.com/mas_cnp_merchant_interface\">"
//				+ "<version>1.0</version><TxnMsgContent><txnType>PUR</txnType><interactiveStatus>TR1</interactiveStatus><merchantId>812310045110196</merchantId><terminalId>00002115</terminalId><entryTime>20160330104356</entryTime><cardNo>4581240910584102</cardNo><expiredDate>0520</expiredDate><amount>1.00</amount><externalRefNumber>T0000816657</externalRefNumber><tr3Url>http://183.91.145.196:7080/bill99/bill99tr3.do</tr3Url><ext>kao</ext><ext1>EJ0330104352</ext1><extMap><extDate><key>cellPhone</key><value>13611153356</value></extDate><extDate><key>idType</key><value>0</value></extDate><extDate><key>phone</key><value>13611153356</value></extDate></extMap></TxnMsgContent></MasMessage>";
				+ "<version>1.0</version><TxnMsgContent><txnType>PUR</txnType><interactiveStatus>TR1</interactiveStatus><merchantId>812310045110196</merchantId><terminalId>00002115</terminalId><entryTime>20160406170024</entryTime><cardNo>4581240910584102</cardNo><expiredDate>0520</expiredDate><amount>0.10</amount><externalRefNumber>T0000816691</externalRefNumber><tr3Url>http://183.91.145.196:7080/bill99/bill99tr3.do</tr3Url><ext>kao</ext><ext1>EJ0406170024</ext1><extMap><extDate><key>cellPhone</key><value>13611153356</value></extDate><extDate><key>idType</key><value>0</value></extDate><extDate><key>phone</key><value>13611153356</value></extDate></extMap></TxnMsgContent></MasMessage>";

		Bill99Service uti = Bill99Service.getInstance();
		System.out.println(xml);
		String x = uti.send("https://mas.99bill.com:443/cnp/purchase",
				xml, true,"SHA");
		System.out.println(x);
	}
	public void test(){
		try {
			// System.setProperty("jsse.enableSNIExtension", "false");
			System.out.println(System.getProperty("jsse.enableSNIExtension"));
			// String xml1 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
			// +
			// "<MasMessage xmlns=\"http://www.99bill.com/mas_cnp_merchant_interface\">"
			// +
			// "<version>1.0</version><TxnMsgContent><txnType>PUR</txnType><interactiveStatus>TR1</interactiveStatus><merchantId>812310045110196</merchantId><terminalId>00002115</terminalId><entryTime>20160329181859</entryTime><cardNo>4581240910584102</cardNo><expiredDate>0520</expiredDate><amount>1.00</amount><externalRefNumber>T0000816653</externalRefNumber><tr3Url>http://183.91.145.196:7080/bill99/bill99tr3.do</tr3Url><ext>kao</ext><ext1>EJ0329181822</ext1><extMap><extDate><key>cellPhone</key><value>13611153356</value></extDate><extDate><key>idType</key><value>0</value></extDate><extDate><key>phone</key><value>13611153356</value></extDate></extMap></TxnMsgContent></MasMessage>";
			String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
					+ "<MasMessage xmlns=\"http://www.99bill.com/mas_cnp_merchant_interface\">"
					// +
					// "<version>1.0</version><TxnMsgContent><txnType>PUR</txnType><interactiveStatus>TR1</interactiveStatus><merchantId>812310045110196</merchantId><terminalId>00002115</terminalId><entryTime>20160330104356</entryTime><cardNo>4581240910584102</cardNo><expiredDate>0520</expiredDate><amount>1.00</amount><externalRefNumber>T0000816657</externalRefNumber><tr3Url>http://183.91.145.196:7080/bill99/bill99tr3.do</tr3Url><ext>kao</ext><ext1>EJ0330104352</ext1><extMap><extDate><key>cellPhone</key><value>13611153356</value></extDate><extDate><key>idType</key><value>0</value></extDate><extDate><key>phone</key><value>13611153356</value></extDate></extMap></TxnMsgContent></MasMessage>";
					+ "<version>1.0</version><TxnMsgContent><txnType>PUR</txnType><interactiveStatus>TR1</interactiveStatus><merchantId>812310045110196</merchantId><terminalId>00002115</terminalId><entryTime>20160406170024</entryTime><cardNo>4581240910584102</cardNo><expiredDate>0520</expiredDate><amount>0.10</amount><externalRefNumber>T0000816691</externalRefNumber><tr3Url>http://183.91.145.196:7080/bill99/bill99tr3.do</tr3Url><ext>kao</ext><ext1>EJ0406170024</ext1><extMap><extDate><key>cellPhone</key><value>13611153356</value></extDate><extDate><key>idType</key><value>0</value></extDate><extDate><key>phone</key><value>13611153356</value></extDate></extMap></TxnMsgContent></MasMessage>";

			Bill99Service uti = Bill99Service.getInstance();
			System.out.println(xml);
			String x = uti.send("https://mas.99bill.com:443/cnp/purchase", xml,
					true, "SHA");
			System.out.println(x);
		} catch (Exception e) {
			System.out.println("error");
			e.printStackTrace();
		}
	}
}
