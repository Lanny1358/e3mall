package com.citsamex.test;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.junit.Test;

import com.citsamex.core.card.bill99.AttachInfo;
import com.citsamex.core.card.bill99.BaseForm;
import com.citsamex.core.card.bill99.Bill99Callback;
import com.citsamex.core.card.bill99.Bill99Service;
import com.citsamex.core.card.bill99.PurchaseForm;
import com.citsamex.core.card.bill99.RefundForm;
import com.citsamex.core.card.bill99.VoidForm;

public class Bill99Util {
	private static SimpleDateFormat datetimeformat = new SimpleDateFormat(
			"yyyyMMddHHmmss");

	public static String formatEntryDate() {
		return datetimeformat.format(new Date());
	}

	public void testPurchase() throws Exception {
		PurchaseForm form = new PurchaseForm();
		form.setTerminalId(Bill99Service.getProperty("terminalId"));
		form.setMerchantId(Bill99Service.getProperty("merchantId"));
		form.setEntryTime(Bill99Util.formatEntryDate());

		form.setCardNo("5528010000000001");
		form.setExpiredDate("0913");
		form.setAmount("100.20");
		form.setExternalRefNumber("0000256661");
		form.setCardHolderName("zhang xin");
		form.setCardHolderId("00000111");
		// form.setCvv2("012");
		// form.setTr3Url("http://210.13.127.41:7080/bill99/bill99tr3.do");
		try {
			send(form);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testVoid() {
		VoidForm form = new VoidForm();
		form.setMerchantId("106110065110002");
		form.setTerminalId("10101061");
		form.setEntryTime("20120405140420");
		form.setAmount("100.20");
		form.setExternalRefNumber("0000256661");
		form.setOrignalTxnType("PUR");
		form.setRefNumber("000008328884");
		try {
			send(form);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void testRefund() {
		RefundForm form = new RefundForm();
		form.setMerchantId("106110065110002");
		form.setTerminalId("10101061");
		form.setEntryTime("20120405140420");
		form.setAmount("100.20");
		form.setExternalRefNumber("000001");
		form.setOrigRefNumber("000008327494");
//		form.setCustomerId("00000111");
	}

	public static Bill99Callback send(BaseForm form) throws Exception {
		String xml = form.toXML();
		Bill99Service uti = Bill99Service.getInstance();
//		String retXml = uti.send(Bill99Service.getProperty("tr1"), xml, true);
//		Bill99Callback callback = Bill99Callback.load(retXml);
//		System.out.println(retXml);
		//2.0 demo
		Logger.getRootLogger().info("tr1_test :" + Bill99Service.getProperty("tr1_test"));
		String retXml = uti.send(Bill99Service.getProperty("tr1_test"), xml, true);
		Logger.getRootLogger().warn(retXml);	
		Bill99Callback callback = Bill99Callback.load(retXml);
		return callback;
	}

	public static Bill99Callback send(BaseForm form, AttachInfo info)
			throws Exception {
		String xml = form.toXML();
		Bill99Service uti = Bill99Service.getInstance();
		Logger.getRootLogger().info("this invoice from :" + info.getLocation());
		if (info.getLocation() == null) {
			Logger.getRootLogger().warn("can not locate this transaction!!!");
			Logger.getRootLogger().warn("transaction data by xml:" + xml);
		}
//		String retXml = uti.send(Bill99Service.getProperty("tr1"), xml, true,info.getLocation());
		//注释掉,走测试环境
//		String property = System.getProperty("jsse.enableSNIExtension");
//		System.out.println(property);
		Logger.getRootLogger().info("tr1 :" + Bill99Service.getProperty("tr1"));
		String retXml = uti.send(Bill99Service.getProperty("tr1"), xml, true,info.getLocation());
		//2.0 demo
//		Logger.getRootLogger().info("tr1_test :" + Bill99Service.getProperty("tr1_test"));
//		String retXml = uti.send(Bill99Service.getProperty("tr1_test"), xml, true);
		Logger.getRootLogger().warn(retXml);
		Bill99Callback callback = Bill99Callback.load(retXml);
		return callback;
	}
	public static Bill99Callback query(BaseForm form) throws Exception {
		String xml = form.toXML();
		Bill99Service uti = Bill99Service.getInstance();
		//2.0 demo
		String retXml = uti.query(Bill99Service.getProperty("query_test"), xml, true);
		Logger.getRootLogger().warn(retXml);
		Bill99Callback callback = Bill99Callback.load(retXml);
		return callback;
	}
	public static Bill99Callback query(BaseForm form, AttachInfo info)
			throws Exception {
		String xml = form.toXML();
		Bill99Service uti = Bill99Service.getInstance();
		Logger.getRootLogger().info("this invoice from :" + info.getLocation());
		if (info.getLocation() == null) {
			Logger.getRootLogger().warn("can not locate this transaction!!!");
			Logger.getRootLogger().warn("transaction data by xml:" + xml);
		}
//		Logger.getRootLogger().info("query_url :" + Bill99Service.getProperty("query_url"));
		//2.0 demo
		String retXml = uti.query(Bill99Service.getProperty("query_url"), xml, true,info.getLocation());
		Logger.getRootLogger().warn(retXml);
		Bill99Callback callback = Bill99Callback.load(retXml);
		return callback;
	}
	public static void main(String[] args) {
		Bill99Service uti = Bill99Service.getInstance();
	}
}
