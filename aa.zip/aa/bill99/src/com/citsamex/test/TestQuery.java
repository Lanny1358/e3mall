package com.citsamex.test;

import com.citsamex.core.card.bill99.Bill99Callback;
import com.citsamex.core.card.bill99.Bill99Service;
import com.citsamex.core.card.bill99.QueryForm;

public class TestQuery {
	public static void main(String[] args) throws Exception {
		System.setProperty("jsse.enableSNIExtension", "false");
		Bill99Service bs = Bill99Service.getInstance();
		QueryForm queryForm = new QueryForm();
		queryForm.setExternalRefNumber("T0000262068");
//		queryForm.setRefNumber("000012991870");
//		queryForm.setExternalRefNumber("T0000222042");
		queryForm.setTxnType("PUR");
//		queryForm.setMerchantId("812310045110196");
//		queryForm.setTerminalId("00002115");
		queryForm.setMerchantId("812310045110196");
		queryForm.setTerminalId("00002115");
		//EJ0405094435
		String local = "SHA";
		boolean isSSL = true;
		String content = queryForm.toXML();
		String retXml = bs.query(Bill99Service.getProperty("query_url"), content, isSSL,"SHA");
		Bill99Callback callback = Bill99Callback.load(retXml);
		System.out.println(retXml);
//		<?xml version="1.0" encoding="UTF-8" standalone="yes"?><MasMessage xmlns="http://www.99bill.com/mas_cnp_merchant_interface"><version>1.0</version><QryTxnMsgContent><externalRefNumber>T0000816683</externalRefNumber><txnType>VTX</txnType><merchantId>812111745110001</merchantId><terminalId>33120002</terminalId></QryTxnMsgContent><TxnMsgContent><txnType>VTX</txnType><amount>111</amount><merchantId>812111745110001</merchantId><terminalId>33120002</terminalId><entryTime>20160331182416</entryTime><externalRefNumber>T0000816683</externalRefNumber><transTime>20160331182417</transTime><voidFlag>0</voidFlag><refNumber>000012986713</refNumber><responseCode>00</responseCode><responseTextMessage></responseTextMessage><cardOrg>CU</cardOrg><issuer>交通银行</issuer><storableCardNo>4581244102</storableCardNo><authorizationCode>771742</authorizationCode><txnStatus>S</txnStatus></TxnMsgContent></MasMessage>

	
		System.out.println(callback);
	}
}
