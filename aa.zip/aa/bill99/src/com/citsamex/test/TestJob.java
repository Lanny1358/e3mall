package com.citsamex.test;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class TestJob implements ServletContextListener{

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		// TODO Auto-generated method stub
		new Thread(){
			@Override
			public void run() {
				try {
					Thread.sleep(20*1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				TestPurchase tp = new TestPurchase();
				tp.test();
				System.out.println("over");
			}
		}.start();
	}

}
