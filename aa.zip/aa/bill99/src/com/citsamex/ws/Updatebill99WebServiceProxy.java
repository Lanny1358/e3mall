package com.citsamex.ws;

public class Updatebill99WebServiceProxy implements com.citsamex.ws.Updatebill99WebService {
  private String _endpoint = null;
  private com.citsamex.ws.Updatebill99WebService updatebill99WebService = null;
  
  public Updatebill99WebServiceProxy() {
    _initUpdatebill99WebServiceProxy();
  }
  
  public Updatebill99WebServiceProxy(String endpoint) {
    _endpoint = endpoint;
    _initUpdatebill99WebServiceProxy();
  }
  
  private void _initUpdatebill99WebServiceProxy() {
    try {
      updatebill99WebService = (new com.citsamex.ws.Updatebill99WebServiceServiceLocator()).getUpdatebill99WebService();
      if (updatebill99WebService != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)updatebill99WebService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)updatebill99WebService)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (updatebill99WebService != null)
      ((javax.xml.rpc.Stub)updatebill99WebService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.citsamex.ws.Updatebill99WebService getUpdatebill99WebService() {
    if (updatebill99WebService == null)
      _initUpdatebill99WebServiceProxy();
    return updatebill99WebService;
  }
  
  public void update(java.lang.String xml) throws java.rmi.RemoteException{
    if (updatebill99WebService == null)
      _initUpdatebill99WebServiceProxy();
    updatebill99WebService.update(xml);
  }
  
  
}