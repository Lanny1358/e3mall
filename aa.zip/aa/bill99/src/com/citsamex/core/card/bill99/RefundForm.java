package com.citsamex.core.card.bill99;

public class RefundForm extends BaseForm {
	@SuppressWarnings("unused")
	private String txnType = "RFD";
	@SuppressWarnings("unused")
	private String interactiveStatus = "TR1";
	private String merchantId;
	private String terminalId;
	private String entryTime;
	private String amount;
	private String externalRefNumber;
	private String origRefNumber;
//	正式环境中没有
//	private String customerId;

	
	// use extend field
	// "ext" use for make a difference from oax
	private String ext = "kao";
	private String ext1;
	
	public String getTxnType() {
		return "RFD";
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	public String getEntryTime() {
		return entryTime;
	}

	public void setEntryTime(String entryTime) {
		this.entryTime = entryTime;
	}

	public String getInteractiveStatus() {
		return "TR1";
	}

	public void setInteractiveStatus(String interactiveStatus) {
		this.interactiveStatus = interactiveStatus;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getExternalRefNumber() {
		return externalRefNumber;
	}

	public void setExternalRefNumber(String externalRefNumber) {
		this.externalRefNumber = externalRefNumber;
	}

	public String getOrigRefNumber() {
		return origRefNumber;
	}

	public void setOrigRefNumber(String origRefNumber) {
		this.origRefNumber = origRefNumber;
	}

//	public String getCustomerId() {
//		return customerId;
//	}
//
//	public void setCustomerId(String customerId) {
//		this.customerId = customerId;
//	}

	/**
	 * "ext" use for make a difference from oax
	 * @return
	 */
	public String getExt() {
		return ext;
	}

	public void setExt(String ext) {
		this.ext = ext;
	}	
	
	public String getExt1() {
		return ext1;
	}

	public void setExt1(String ext1) {
		this.ext1 = ext1;
	}
}
