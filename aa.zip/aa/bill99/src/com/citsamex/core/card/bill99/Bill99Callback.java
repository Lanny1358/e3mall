package com.citsamex.core.card.bill99;

import java.io.StringReader;
import java.lang.reflect.Field;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

public class Bill99Callback extends BaseForm {
	private String txnType;
	private String interactiveStatus;
	private String amount;
	private String merchantId;
	private String terminalId;
	private String entryTime;
	private String externalRefNumber;
	private String customerId;
	private String transTime;
	private String refNumber;
	private String responseCode;
	private String responseTextMessage;
	private String cardOrg;
	private String issuer;
	private String storableCardNo;
	private String authorizationCode;
	private String origRefNumber;
	private String errorCode;

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public String getInteractiveStatus() {
		return interactiveStatus;
	}

	public void setInteractiveStatus(String interactiveStatus) {
		this.interactiveStatus = interactiveStatus;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	public String getEntryTime() {
		return entryTime;
	}

	public void setEntryTime(String entryTime) {
		this.entryTime = entryTime;
	}

	public String getExternalRefNumber() {
		return externalRefNumber;
	}

	public void setExternalRefNumber(String externalRefNumber) {
		this.externalRefNumber = externalRefNumber;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getTransTime() {
		return transTime;
	}

	public void setTransTime(String transTime) {
		this.transTime = transTime;
	}

	public String getRefNumber() {
		return refNumber;
	}

	public void setRefNumber(String refNumber) {
		this.refNumber = refNumber;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseTextMessage() {
		return responseTextMessage;
	}

	public void setResponseTextMessage(String responseTextMessage) {
		this.responseTextMessage = responseTextMessage;
	}

	public String getCardOrg() {
		return cardOrg;
	}

	public void setCardOrg(String cardOrg) {
		this.cardOrg = cardOrg;
	}

	public String getIssuer() {
		return issuer;
	}

	public void setIssuer(String issuer) {
		this.issuer = issuer;
	}

	public String getStorableCardNo() {
		return storableCardNo;
	}

	public void setStorableCardNo(String storableCardNo) {
		this.storableCardNo = storableCardNo;
	}

	public String getAuthorizationCode() {
		return authorizationCode;
	}

	public void setAuthorizationCode(String authorizationCode) {
		this.authorizationCode = authorizationCode;
	}

	public String getOrigRefNumber() {
		return origRefNumber;
	}

	public void setOrigRefNumber(String origRefNumber) {
		this.origRefNumber = origRefNumber;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public static Bill99Callback load(String xml) {
		Bill99Callback callback = new Bill99Callback();

		xml = filter(xml);
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder;
		try {
			builder = factory.newDocumentBuilder();
			InputSource is = new InputSource(new StringReader(xml));
			Document doc = builder.parse(is);
			XPathFactory xpathFactory = XPathFactory.newInstance();

			if (xml.indexOf("errorCode") != -1) {
				callback.setErrorCode(xml.substring(xml.indexOf("<errorCode>")
						+ "<errorCode>".length(), xml.indexOf("</errorCode>")));
			} else {
				Field[] fields = callback.getClass().getDeclaredFields();
				for (int i = 0; i < fields.length; i++) {
					String fieldname = fields[i].getName();

					try {
						XPathExpression expr = xpathFactory.newXPath().compile(
								"/MasMessage/TxnMsgContent/" + fieldname);
						Node node = (Node) expr.evaluate(doc,
								XPathConstants.NODE);
						if (node != null) {
							String value = node.getTextContent();
							callback.setValue(fieldname, value);
						}
					} catch (XPathExpressionException e) {
						e.printStackTrace();
					} catch (IllegalArgumentException e) {
						e.printStackTrace();
					} catch (IllegalAccessException e) {
						e.printStackTrace();
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return callback;

	}

	private static String filter(String xml) {
		xml = xml.replaceAll("&#x0;", "");
		xml = xml.replaceAll("&#x1F;", "");
		return xml;
	}
	
	@Override
	public String toString() {
		String ret = this.txnType + "," + this.terminalId + ","
				+ this.merchantId + "," + this.refNumber + "," 
				+ this.interactiveStatus + "," + this.responseCode + "," 
				+ this.responseTextMessage + "," + this.errorCode;
		return ret;
	}
}
