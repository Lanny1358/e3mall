package com.citsamex.core.card.bill99;

public class TR4 extends BaseForm {
	private String txnType;
	private String interactiveStatus;
	private String merchantId;
	private String settleMerchantId;
	private String terminalId;
	private String refNumber;

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public String getInteractiveStatus() {
		return interactiveStatus;
	}

	public void setInteractiveStatus(String interactiveStatus) {
		this.interactiveStatus = interactiveStatus;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getSettleMerchantId() {
		return settleMerchantId;
	}

	public void setSettleMerchantId(String settleMerchantId) {
		this.settleMerchantId = settleMerchantId;
	}

	public String getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	public String getRefNumber() {
		return refNumber;
	}

	public void setRefNumber(String refNumber) {
		this.refNumber = refNumber;
	}

	@Override
	public String toString() {
		String ret = this.txnType + "," + this.terminalId + ","
				+ this.merchantId + "," + this.refNumber + this.interactiveStatus;
		return ret;
	}

	
}