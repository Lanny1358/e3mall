package com.citsamex.core.card.bill99;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyStore;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Properties;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.log4j.Logger;

public class Bill99Service {
	private final static Bill99Service uti = new Bill99Service();
	private static Properties props = new Properties();
	static {
		try {
			props.load(Bill99Service.class
					.getResourceAsStream("bill99.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private Bill99Service() {

	}

	public static String getProperty(String propertyName) {
		return props.getProperty(propertyName);
	}

	public static Bill99Service getInstance() {
		return uti;
	}

	public String send(String urlStr, String content, boolean isSSL)
			throws Exception {

		String certfile = props.getProperty("certfile");
		String password = props.getProperty("password");
		String merchantId = props.getProperty("merchantId");
		Logger.getRootLogger().info("certfile " + certfile);
		Logger.getRootLogger().info("password " + password);
		Logger.getRootLogger().info("merchantId " + merchantId);
		Logger.getRootLogger().info("content " + content);
		SSLSocketFactory factory = null;
		if (isSSL) {
			factory = createSSLFactory(certfile, password);
		}

		HttpURLConnection urlconnection = createHttpsUrlConnection(urlStr,
				factory);

		String authString = merchantId + ":" + password;
		String auth = "Basic "
				+ Base64Binrary.encodeBase64Binrary(authString.getBytes());
		urlconnection.setRequestProperty("Authorization", auth);

		OutputStream out = urlconnection.getOutputStream();
		out.write(content.getBytes());
		out.flush();
		out.close();
		InputStream is = urlconnection.getInputStream();
		return processReturn(is);
	}

	public String send(String urlStr, String content, boolean isSSL,String local) 
			throws Exception {
		String certfile = null;
		String password = null;
		String merchantId = null;

		if ("BJS".equals(local)) {
			certfile = props.getProperty("BJS_certfile");
			password = props.getProperty("BJS_password");
			merchantId = props.getProperty("BJS_merchantId");
		} else if ("SHA".equals(local)) {
			certfile = props.getProperty("SHA_certfile");
			password = props.getProperty("SHA_password");
			merchantId = props.getProperty("SHA_merchantId");
		} else if ("CAN".equals(local)) {
			certfile = props.getProperty("CAN_certfile");
			password = props.getProperty("CAN_password");
			merchantId = props.getProperty("CAN_merchantId");
		}
		Logger.getRootLogger().info("certfile " + certfile);
		Logger.getRootLogger().info("password " + password);
		Logger.getRootLogger().info("merchantId " + merchantId);
		Logger.getRootLogger().info("content " + content);
		SSLSocketFactory factory = null;
		if (isSSL) {
			factory = createSSLFactory(certfile, password);
		}

		HttpURLConnection urlconnection = createHttpsUrlConnection(urlStr,
				factory);

		String authString = merchantId + ":" + password;
		String auth = "Basic "
				+ Base64Binrary.encodeBase64Binrary(authString.getBytes());
		urlconnection.setRequestProperty("Authorization", auth);

		OutputStream out = urlconnection.getOutputStream();
		out.write(content.getBytes());
		out.flush();
		out.close();
		InputStream is = urlconnection.getInputStream();
		return processReturn(is);
	}
	
	public String query(String urlStr, String content, boolean isSSL)
			throws Exception {

		String certfile = props.getProperty("certfile");
		String password = props.getProperty("password");
		String merchantId = props.getProperty("merchantId");
		Logger.getRootLogger().info("certfile " + certfile);
		Logger.getRootLogger().info("password " + password);
		Logger.getRootLogger().info("merchantId " + merchantId);
		Logger.getRootLogger().info("content " + content);
		SSLSocketFactory factory = null;
		if (isSSL) {
			factory = createSSLFactory(certfile, password);
		}

		HttpURLConnection urlconnection = createHttpsUrlConnection(urlStr,
				factory);

		String authString = merchantId + ":" + password;
		String auth = "Basic "
				+ Base64Binrary.encodeBase64Binrary(authString.getBytes());
		urlconnection.setRequestProperty("Authorization", auth);

		OutputStream out = urlconnection.getOutputStream();
		out.write(content.getBytes());
		out.flush();
		out.close();
		InputStream is = urlconnection.getInputStream();
		return processReturn(is);
	}
	
	public String query(String urlStr, String content, boolean isSSL,
			String local) throws Exception {
		String certfile = null;
		String password = null;
		String merchantId = null;
		
		if ("BJS".equals(local)) {
			certfile = props.getProperty("BJS_certfile");
			password = props.getProperty("BJS_password");
			merchantId = props.getProperty("BJS_merchantId");
		} else if ("SHA".equals(local)) {
			certfile = props.getProperty("SHA_certfile");
			password = props.getProperty("SHA_password");
			merchantId = props.getProperty("SHA_merchantId");
		} else if ("CAN".equals(local)) {
			certfile = props.getProperty("CAN_certfile");
			password = props.getProperty("CAN_password");
			merchantId = props.getProperty("CAN_merchantId");
		}
		Logger.getRootLogger().info("certfile " + certfile);
		Logger.getRootLogger().info("password " + password);
		Logger.getRootLogger().info("merchantId " + merchantId);
		Logger.getRootLogger().info("content " + content);
		SSLSocketFactory factory = null;
		if (isSSL) {
			factory = createSSLFactory(certfile, password);
		}
		
		HttpURLConnection urlconnection = createHttpsUrlConnection(urlStr,
				factory);
		
		String authString = merchantId + ":" + password;
		String auth = "Basic "
				+ Base64Binrary.encodeBase64Binrary(authString.getBytes());
		urlconnection.setRequestProperty("Authorization", auth);
		
		OutputStream out = urlconnection.getOutputStream();
		out.write(content.getBytes());
		out.flush();
		out.close();
		InputStream is = urlconnection.getInputStream();
		return processReturn(is);
	}

	private String processReturn(InputStream is) throws Exception {
		String retVal = "";
		if (is != null) {
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			byte[] receiveBuffer = new byte[2048];
			int readBytesSize = is.read(receiveBuffer);
			while (readBytesSize != -1) {
				bos.write(receiveBuffer, 0, readBytesSize);
				readBytesSize = is.read(receiveBuffer);
			}
			retVal = new String(bos.toByteArray(), "UTF-8");
			// respXml = ParseUtil.parseXML(reqData);
		}

		return retVal;
	}

	private SSLSocketFactory createSSLFactory(String certfile, String password)
			throws Exception {

		KeyStore ks = KeyStore.getInstance("JKS");
		ks.load(Bill99Service.class.getResourceAsStream(certfile),
				password.toCharArray());

		KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory
				.getDefaultAlgorithm());
		kmf.init(ks, password.toCharArray());

		TrustManager[] tm = { new DefaultX509TrustManager() };
		SSLContext sslContext = SSLContext.getInstance("SSL");

		sslContext.init(kmf.getKeyManagers(), tm, null);
		SSLSocketFactory factory = sslContext.getSocketFactory();
		return factory;
	}

	private HttpURLConnection createHttpsUrlConnection(String urlStr,
			SSLSocketFactory factory) throws Exception {
		URL url = new URL(urlStr);
		HttpURLConnection urlconnection = null;
		if (factory == null) {
			urlconnection = (HttpURLConnection) url.openConnection();
		} else {
			urlconnection = (HttpsURLConnection) url.openConnection();
			((HttpsURLConnection) urlconnection).setSSLSocketFactory(factory);
		}

		urlconnection.setDoOutput(true);
		urlconnection.setDoInput(true);
		urlconnection.setReadTimeout(60 * 1000);
		return urlconnection;
	}

	class DefaultX509TrustManager implements X509TrustManager {

		public DefaultX509TrustManager() throws Exception {
		}

		public void checkClientTrusted(X509Certificate[] chain, String authType)
				throws CertificateException {
		}

		public void checkServerTrusted(X509Certificate[] chain, String authType)
				throws CertificateException {
		}

		public X509Certificate[] getAcceptedIssuers() {
			return new java.security.cert.X509Certificate[0];
		}
	}

	public static void main(String args[]) throws Exception {
//		System.setProperty("jsse.enableSNIExtension", "false");
		System.out.println(System.getProperty("jsse.enableSNIExtension"));
//		String xml1 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
//				+ "<MasMessage xmlns=\"http://www.99bill.com/mas_cnp_merchant_interface\">"
//				+ "<version>1.0</version><TxnMsgContent><txnType>PUR</txnType><interactiveStatus>TR1</interactiveStatus><merchantId>812310045110196</merchantId><terminalId>00002115</terminalId><entryTime>20160329181859</entryTime><cardNo>4581240910584102</cardNo><expiredDate>0520</expiredDate><amount>1.00</amount><externalRefNumber>T0000816653</externalRefNumber><tr3Url>http://183.91.145.196:7080/bill99/bill99tr3.do</tr3Url><ext>kao</ext><ext1>EJ0329181822</ext1><extMap><extDate><key>cellPhone</key><value>13611153356</value></extDate><extDate><key>idType</key><value>0</value></extDate><extDate><key>phone</key><value>13611153356</value></extDate></extMap></TxnMsgContent></MasMessage>";
		String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
				+ "<MasMessage xmlns=\"http://www.99bill.com/mas_cnp_merchant_interface\">"
//				+ "<version>1.0</version><TxnMsgContent><txnType>PUR</txnType><interactiveStatus>TR1</interactiveStatus><merchantId>812310045110196</merchantId><terminalId>00002115</terminalId><entryTime>20160330104356</entryTime><cardNo>4581240910584102</cardNo><expiredDate>0520</expiredDate><amount>1.00</amount><externalRefNumber>T0000816657</externalRefNumber><tr3Url>http://183.91.145.196:7080/bill99/bill99tr3.do</tr3Url><ext>kao</ext><ext1>EJ0330104352</ext1><extMap><extDate><key>cellPhone</key><value>13611153356</value></extDate><extDate><key>idType</key><value>0</value></extDate><extDate><key>phone</key><value>13611153356</value></extDate></extMap></TxnMsgContent></MasMessage>";
				+ "<version>1.0</version><TxnMsgContent><txnType>PUR</txnType><interactiveStatus>TR1</interactiveStatus><merchantId>812310045110196</merchantId><terminalId>00002115</terminalId><entryTime>20160406170024</entryTime><cardNo>4581240910584102</cardNo><expiredDate>0520</expiredDate><amount>0.10</amount><externalRefNumber>T0000816691</externalRefNumber><tr3Url>http://183.91.145.196:7080/bill99/bill99tr3.do</tr3Url><ext>kao</ext><ext1>EJ0406170024</ext1><extMap><extDate><key>cellPhone</key><value>13611153356</value></extDate><extDate><key>idType</key><value>0</value></extDate><extDate><key>phone</key><value>13611153356</value></extDate></extMap></TxnMsgContent></MasMessage>";

		Bill99Service uti = Bill99Service.getInstance();
		System.out.println(xml);
		String x = uti.send("https://mas.99bill.com:443/cnp/purchase",
				xml, true,"SHA");
		System.out.println(x);

	}

}
