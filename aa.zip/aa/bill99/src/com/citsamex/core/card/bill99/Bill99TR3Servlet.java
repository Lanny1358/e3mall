package com.citsamex.core.card.bill99;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.rpc.ServiceException;

import org.apache.log4j.Logger;

import com.citsamex.ws.Updatebill99WebService;
import com.citsamex.ws.Updatebill99WebServiceProxy;
import com.citsamex.ws.Updatebill99WebServiceServiceLocator;

/**
 * Servlet implementation class Bill99TR3
 */
@WebServlet("/Bill99TR3")
public class Bill99TR3Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Bill99TR3Servlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.getOutputStream().println("Tr3 is running normally!");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		String ip = request.getRemoteAddr();
		//TODO  2.0demo
		Logger.getRootLogger().info(ip);
		if (!restrictIp(ip)) {
			Logger.getRootLogger().warn("this ip not allow to access : " + ip);
			return;
		}

//		System.out.println("ready to deal with the feedback data !");
		Logger.getRootLogger().info("ready to deal with the feedback data !");
		InputStream is = request.getInputStream();
		byte[] receiveBuffer = new byte[2048];
		is.read(receiveBuffer);
		String xml = new String(receiveBuffer).trim();
		Logger.getRootLogger().info(xml);
		Bill99Callback callback = Bill99Callback.load(xml);
		Logger.getRootLogger().info(callback.toString());
		Updatebill99WebService services = new Updatebill99WebServiceProxy();
		services.update(xml);
//		try {
//			Updatebill99WebServiceServiceLocator locator = new Updatebill99WebServiceServiceLocator();
//			Updatebill99WebService service = locator.getUpdatebill99WebService();
//			Updatebill99WebService service = locator.getUpdatebill99WebService(new URL("http://localhost:8080/kaoii/services/Updatebill99WebService?wsdl"));
//			service.update(xml);
//		} catch (ServiceException e1) {
//			Logger.getRootLogger().warn("webservice error" + e1);
//		}

		TR4 tr4 = new TR4();
		tr4.setTxnType(callback.getTxnType());
		tr4.setMerchantId(callback.getMerchantId());
		tr4.setRefNumber(callback.getRefNumber());
		tr4.setInteractiveStatus("TR4");
		tr4.setTerminalId(callback.getTerminalId());
		// tr4.settleMerchantId = callback.getMerchantId();
		try {
			Logger.getRootLogger().info(tr4.toXML());
			response.getOutputStream().write(tr4.toXML().getBytes("UTF-8"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private boolean restrictIp(String ip) {
		String ipls = Bill99Service.getProperty("allow.ip");
		if (ipls != null && !ipls.equals("")) {
			String[] ips = ipls.split(",");
			for (int i = 0; i < ips.length; i++) {
				if (ip.equals(ips[i])) {
					return true;
				}
				String orgIpspans[] = ip.split("\\.");
				String spans[] = ips[i].split("\\.");

				String allowIp = "";
				if (spans.length == 4) {
					for (int j = 0; j < spans.length; j++) {
						if (spans[j].equals("*")) {
							allowIp += orgIpspans[j];
						} else {
							allowIp += spans[j];
						}
						if (j != 3) {
							allowIp += ".";
						}
					}
					if (allowIp.equals(ip)) {
						return true;
					}
				}
			}
		}

		return false;
	}

	public static void main(String[] args) {
		new Bill99TR3Servlet().restrictIp("10.181.10.129");
	}
}
