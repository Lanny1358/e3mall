package com.citsamex.core.card.bill99;

import java.lang.reflect.Field;

public abstract class BaseForm {
	private final static String XMLDEF = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
	private final static String XMLHEAD = "<MasMessage xmlns=\"http://www.99bill.com/mas_cnp_merchant_interface\">";
	private final static String XMLVER = "<version>1.0</version>";
	private final static String XMLROOT = "<TxnMsgContent>";
	private final static String XMLTAIL = "</TxnMsgContent></MasMessage>";
	private final static String XMLQryROOT = "<QryTxnMsgContent>";
	private final static String XMLQryTAIL = "</QryTxnMsgContent></MasMessage>";

	public String toXML() throws Exception {
		StringBuffer buffer = new StringBuffer();
		StringBuffer buffer2 = new StringBuffer();
		buffer.append(XMLDEF);
		buffer.append(XMLHEAD);
		buffer.append(XMLVER);
//		buffer.append(XMLROOT);

		if(this instanceof com.citsamex.core.card.bill99.QueryForm){
			buffer.append(XMLQryROOT);
		}else{
			buffer.append(XMLROOT);
		}
		Field fields[] = this.getClass().getDeclaredFields();
		for (int i = 0; i < fields.length; i++) {
			String name = fields[i].getName();
			String value = (String) getValue(name);
			if (value != null && !value.equals("")) {
				if (name.equals("cellPhone") || name.equals("idType") || name.equals("phone")) {
					buffer2.append(tag2(name, value));
				} else {
					buffer.append(tag(name, value));
				}

			}
		}

		String ext = buffer2.toString();
		if (!ext.equals("")) {
			buffer.append("<extMap>");
			buffer.append(ext);
			buffer.append("</extMap>");
		}
//		buffer.append(XMLTAIL);
		if(this instanceof com.citsamex.core.card.bill99.QueryForm){
			buffer.append(XMLQryTAIL);
		}else{
			buffer.append(XMLTAIL);
		}
//		System.out.println(buffer.toString());
		return buffer.toString();
	}

	private String tag(String name, String value) {
		return "<" + name + ">" + value + "</" + name + ">";
	}

	private String tag2(String name, String value) {
		return "<extDate><key>" + name + "</key><value>" + value
				+ "</value></extDate>";
	}

	public void setValue(String fieldName, Object value) throws Exception {
		Field field = getClass().getDeclaredField(fieldName);
		String methodName = "set" + fieldName.substring(0, 1).toUpperCase()
				+ fieldName.substring(1);
		getClass().getMethod(methodName, new Class[] { field.getType() })
				.invoke(this, new Object[] { value });
	}

	public Object getValue(String fieldName) throws Exception {
		Object retVal = null;
		String methodName = "get" + fieldName.substring(0, 1).toUpperCase()
				+ fieldName.substring(1);

		retVal = getClass().getMethod(methodName, new Class[] {}).invoke(this,
				new Object[] {});
		return retVal;
	}

	public String toJson() throws Exception {
		StringBuffer buffer = new StringBuffer();
		Field[] fields = getClass().getDeclaredFields();
		buffer.append("{");
		for (int i = 0; i < fields.length; i++) {
			buffer.append("\"" + fields[i].getName() + "\" :");
			buffer.append("\"" + getValue(fields[i].getName()) + "\"");
			if (i < fields.length - 1) {
				buffer.append(",");
			}
		}
		buffer.append("}");
		return buffer.toString();
	}
}
